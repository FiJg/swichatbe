package cz.osu.chatappbe.models;

public enum Status {
	JOIN,
	MESSAGE,
	LEAVE
}
