package cz.osu.chatappbe.models;

import lombok.Getter;

@Getter
public class SignupForm {
	private String username;
	private String password;
}
