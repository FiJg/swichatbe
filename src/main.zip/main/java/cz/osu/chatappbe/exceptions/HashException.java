package cz.osu.chatappbe.exceptions;

public class HashException extends RuntimeException {
	public HashException(String message) {
		super(message);
	}
}
